---
name: Richiesta di informazione (ITA)
about: Richiesta di informazione. Utilizzate questo template se volete comunicare in Italiano
---

<!--
Grazie per aver mostrato interesse in questo repo.
Da sapere prima di aprire issue:
- Questo lavoro è svolto con puro scopo informativo
- Saranno accettate issue relativi a:
  - richieste di informazione
  - richiesta di dati
  - suggerimenti di miglioramento dei documenti, metadati del repo, dashboard grafica, ecc

Prima di aprire un'issue:
  - Fate una breve ricerca degli issue già creati (incluso issue già chiusi) per convincersi che la vostra richiesta non è stata  ancora fatta
  - Sarà apprezzato una spiegazione di come la vostra richiesta beneficierà l'interesse pubblico di questo repo
  - Cancellare il testo sopra
-->

**Tipo di richiesta**: <!-- eliminare tutti non-relativi --> richiesta di informazione | richiesta di dati | suggerimento di miglioramento (documentazione, label, _ecc_) | relativo alla pagina grafica

## Riassunto

<!--
Scrivi qui il riassunto della richiesta.
-->

## Interesse pubblico

<!-- Spiegate in che modo questa richiesta beneficierà l'interesse pubblico -->
